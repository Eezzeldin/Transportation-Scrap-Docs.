###BUILDING UNITS
getdata = function (){
#ALLZONES is the original AirSage Data
#METRO is the original WMATA data
#NEARZONES is the data set produced from ArcMaps ERcs application software.
  #NEARZONES containts the nearest 200 zones to each of the 86 metro stations in metropolean area within a range of 100 miles.
ALLZONES <<- read.csv("long_0514cusWDDP.csv")
METRO <<- read.csv("METRODATA.csv")
NEARZONES <<- read.csv ("Nearest 200 Zones_100 _86 Stations.csv")
}
modifydata = function (){
  ##---ALLZONES Units
  Keep_residentsonly_ALLZONES = function ()   {
    condition = ALLZONES$Subscriber_Class == "Resident"
    ALLZONES <<- ALLZONES [condition==TRUE,] 
  }
  remove_RedundantVariables_ALLZONES = function () {
    ALLZONES$Start_Date  <<- NULL
    ALLZONES$End_Date    <<- NULL
    ALLZONES$Aggregation <<- NULL
    ALLZONES$Subscriber_Class <<-NULL
  }
  make_categorial_variables_asnumeric_ALLZONES = function () {
    ALLZONES$Time_of_Day <<- as.numeric(factor(ALLZONES$Time_of_Day))
    ALLZONES$Purpose     <<- as.numeric(factor(ALLZONES$Purpose)) 
  }
  removenonactivezones_ALLZONES = function (){
    Condition1 = ALLZONES$Origin_Zone %in% NEARZONES$ZONE.ID.TAZ 
    Condition2 = ALLZONES$Destination_Zone %in% NEARZONES$ZONE.ID.TAZ
    Condition3 = Condition1 & Condition2
    ALLZONES <<- ALLZONES [Condition3,]
  }
  makeallzonesnamessameasmetro_ALLZONES = function (StationName) {
    #condition = grepl( METRO [StationNumber, "Ent.Station"],NEARZONES$MetroStnFullPt.NAME)
    condition = grepl( substr(StationName, start=2, stop=7) ,NEARZONES$MetroStnFullPt.NAME)
    TargetedRecords =  NEARZONES [condition,]
    TargetedRecords$MetroStnFullPt.NAME =  sapply (TargetedRecords$MetroStnFullPt.NAME , as.character)
    #TargetedRecords$MetroStnFullPt.NAME  = paste(  METRO [StationNumber, "Ent.Station"])
    #TargetedRecords$MetroStnFullPt.NAME  = paste(StationName)
    NEARZONES [which (grepl( substr(StationName, start=2, stop=7)  ,NEARZONES$MetroStnFullPt.NAME),arr.ind = T),3]  <<- paste(StationName)
    print (NEARZONES [which (grepl( substr(StationName, start=2, stop=7)  ,NEARZONES$MetroStnFullPt.NAME),arr.ind = T),3])
    return (TargetedRecords$MetroStnFullPt.NAME)
  }
  
  ##---METRO Units
  remove_RedundantVariables_METRO = function() {
    #Remove the year and month because I know the analysis runs in may and in 2014.
    METRO$Year.Month <<- NULL 
    METRO$Ent.Date.Holiday <<-NULL #Because the column next it already has this information
  }
  make_categorial_variables_asnumeric_METRO = function () {
    METRO$Ent.Date.Service.Type <<- as.numeric(factor(METRO$Ent.Date.Service.Type))
    METRO$Ent.Time.Period <<- as.numeric(factor(METRO$Ent.Time.Period))
  }
  
  
  ##---NEARZONES
  remove_RedundantVariables_NEARZONES = function (){
    NEARZONES$METRO.STATION.ID <<-NULL
    NEARZONES$NEAR.ZONES.ID    <<-NULL
    NEARZONES$STATION.LATITUDE <<-NULL
    NEARZONES$STATION.LOGITUDE <<-NULL
    NEARZONES$ZONE.LATITUDE    <<-NULL
    NEARZONES$ZONE.LONGITUDE   <<-NULL
    NEARZONES$MetroStnFullPt.GIS_ID <<-NULL
    NEARZONES$MetroStnFullPt.WEB_URL <<-NULL
    NEARZONES$MetroStnFullPt.ADDRESS <<-NULL
  }
  make_categorial_variables_asnumeric_NEARZONES = function () {
    NEARZONES$MetroStnFullPt.LINE <<- as.numeric(factor(NEARZONES$MetroStnFullPt.LINE))
  }
  calculate_distanceinmiles_NEARZONES = function (){
    #The current distance is in meters. For better comprehension , it was transformed in to miles.
    #1 meter = 0.000621371 miles
    NEARZONES$DistanceMiles <<- (NEARZONES$DISTANCE.TO.ZONE..DECIMALS.) * 0.000621371
    NEARZONES$DISTANCE.TO.ZONE..DECIMALS. <<- NULL
  }
  
  
  ##---Execution
  Keep_residentsonly_ALLZONES ()
  remove_RedundantVariables_ALLZONES()
  make_categorial_variables_asnumeric_ALLZONES()
  
  
  remove_RedundantVariables_METRO()
  make_categorial_variables_asnumeric_METRO()
  
  remove_RedundantVariables_NEARZONES ()
  make_categorial_variables_asnumeric_NEARZONES ()
  calculate_distanceinmiles_NEARZONES()
  
  removenonactivezones_ALLZONES()
  #makeallzonesnamessameasmetro_ALLZONES()
  # vector1 = METRO$Ent.Station
  # vector1 = sapply (vector1,as.character)
  # vector1 = unique(vector1)
  # vector1  = vector1 [-c(56,52,75)]
  # lapply (vector1 , function (x)makeallzonesnamessameasmetro_ALLZONES(x) )
  # 
}
writemodifieddata = function (){
write.csv(ALLZONES,"ALLZONES.csv")
write.csv(METRO,"METRO.csv")
write.csv(NEARZONES,"NEARZONES.csv")}

getmodifiedata = function (){
  ALLZONES <<- read.csv("ALLZONES.csv")
  METRO    <<- read.csv("METRO.csv")
  NEARZONES <<- read.csv( "NEARZONES.csv")
}
modifydata_1 = function (){
  ##---BUILDING UNITS
  #ALLZONES
  removecategorial_ALLZONES = function (Purpose,Timeofday) {
    indexes = c()
    indexes = which (ALLZONES$Purpose==Purpose & ALLZONES$Time_of_Day ==Timeofday,arr.ind =FALSE)
    ALLZONES <<-ALLZONES[indexes  ,]
  }
  checkforduplicated_ALLZONES = function (){
    return (which (duplicated (data.frame(ALLZONES$Origin_Zone, ALLZONES$Destination_Zone)) ,arr.ind = TRUE))
  }
  #METRO
  removecategorial_METRO = function (DATE,TimePeriod) {
    METRO <- METRO[ which (METRO$Ent.Date.Service.Type==DATE & METRO$Ent.Time.Period ==TimePeriod ,arr.ind =TRUE),]
    return (METRO)
  }
  
  #NEARZONES
  #The names of NEARZONES had to be changed to match the names in dataset METRO.
  ChangethenamesinNEARZONES_NEARZONES = function (){
    NEARZONES<<- read.csv("NEARZONES_NAMESCHANGED.csv")
  }
  
  
  ##---EXECUTION
  removecategorial_ALLZONES(1,1)#(Purpose: 1:NHB , 2:HBW ,3:HBO,TimeofDay:1:H16:H20 2:H6:H10)
  #METRO    <<-  removecategorial_METRO(1,1) #(Week:1:Weekday , 2:Sunday , 3:Saterday  , Time: 1:AMPeak , 2:Evening , 3:Midday , 4: PM Peak)
  ChangethenamesinNEARZONES_NEARZONES()
  return (paste ("Duplicates in ALLZONES",checkforduplicated_ALLZONES()  ))
}
construct_Predictors = function (){
  #First 2 columns are origin and destination stations
  ##-------CONSTRUCTING UNITS
  add200predictors_closestzones_everystation = function (){
    for (i in 1:200)
      {
      Predictors[1,paste ("Closesness Rank" ,i)] <<-  NA
      }
  }
  #METRO - NEARZONES : Get the nearest 200 zones from NEARZONES for the origin station in METRO
  get_count = function (x){#x: Row number in metro , y:zone Rank 
    ###PREDICTOR ANALYSIS
    Predictors <<- data.frame (METRO$Ent.Station,METRO$Ext.Station)
    get_closest200Zones_x_OriginStation = function (x){
      closest200originstations = c()
      closest200originstations = NEARZONES [ grepl( METRO [x, "Ent.Station"],NEARZONES$MetroStnFullPt.NAME), 2]
      return (closest200originstations)
    } #x here is the row number in the dataframe METRO
    get_closest200Zones_x_DestinationStation = function (x){
      closest200Destinationstations = c()
      closest200Destinationstations = NEARZONES [ grepl( METRO [x, "Ext.Station"],NEARZONES$MetroStnFullPt.NAME), 2]
      return (closest200Destinationstations)
    }
    
    
    ###ZONE ANALYSIS
    O_D <<- data.frame (get_closest200Zones_x_OriginStation(x),get_closest200Zones_x_DestinationStation(x)) #1st_origin_Destination_dataframe
    colnames (O_D) <<- c ("Origin","Destination") #Origin and desitnation zones for the yth station in METRO 
    
    getting_one_zonecombinationcounts = function (y){ #y here is the zone closeness rank
            origin = O_D[y,1] #Origin Zone of rank y
            Destination = O_D [y,2] #Destination Zone of rank y
            #get_count_from_origin_Destination 
            conditoin1 = ALLZONES$Origin_Zone == origin 
            conditoin2 = ALLZONES$Destination_Zone == Destination
            condition3 = conditoin1 & conditoin2
            zonescombination_index_ALLZONES = c()
            zonescombination_index_ALLZONES = which (condition3 , arr.ind = TRUE)
            zonescombination_count = ALLZONES$Count[zonescombination_index_ALLZONES]
            return (zonescombination_count)
            }
    return(lapply (row (O_D), function(x) getting_one_zonecombinationcounts(x)))
  }
  get_count(1) #1: 1st record in METRO dataset 
  
  
  ##--------EXECUTION
  add200predictors_closestzones_everystation()
  
 
 
    
}




####EXECUTION
getdata()
modifydata ()
writemodifieddata()

remove (getdata,writemodifieddata, modifydata)

getmodifiedata ()
modifydata_1()


construct_Predictors ()


###TESTING
